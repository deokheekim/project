package com.boot.board_240214.controller;

import com.boot.board_240214.model.Recipe;
import com.boot.board_240214.service.RecipeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class RecipeController {

    @Autowired
    private RecipeService recipeService;

    @GetMapping("/")
    public String homePage(@RequestParam(name = "search", required = false) String search,
                           @RequestParam(name = "recipeType",required = false, defaultValue = "ingredients") String recipeType,
                           @RequestParam(name = "page", defaultValue = "0") int page,
                           Model model) {

        int pageSize = 15; // 페이지당 결과 수
        Pageable pageable = PageRequest.of(page, pageSize);

        Page<Recipe> recipesPage = recipeService.searchRecipes(search,recipeType,pageable);
        List<Recipe> recipes = recipesPage.getContent();

        model.addAttribute("recipes", recipes);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", recipesPage.getTotalPages());

        return "/index";



//        List<Recipe> recipes = recipeService.searchRecipes(search, recipeType);
//        model.addAttribute("recipes", recipes);
//        model.addAttribute("recipeType", recipeType);
//        return "/index";

    }
}
