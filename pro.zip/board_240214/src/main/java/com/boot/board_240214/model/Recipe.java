package com.boot.board_240214.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class Recipe {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int RCP_SNO;
    private  String RCP_TTL;
    private  String CKG_NM;
    private  int INQ_CNT;
    private  int RCMM_CNT;
    private  int SRAP_CNT;
    private  String CKG_MTH_ACTO_NM;
    private  String CKG_STA_ACTO_NM;
    private  String CKG_MTRL_ACTO_NM;
    private  String CKG_KND_ACTO_NM;
    private  String CKG_IPDC;
    private  String CKG_MTRL_CN;
    private  String CKG_INBUN_NM;
    private  String CKG_DODF_NM;
    private  String CKG_TIME_NM;

    // Getter, Setter 추가
    public String getCKG_NM() {
        return CKG_NM;
    }

    public void setCKG_NM(String CKG_NM) {
        this.CKG_NM = CKG_NM;
    }
}
