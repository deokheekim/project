package com.boot.board_240214.repository;

import com.boot.board_240214.model.Recipe;
import jakarta.persistence.SequenceGenerator;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RecipeRepository extends JpaRepository<Recipe, Long> {

    @Query("SELECT r FROM Recipe r WHERE r.CKG_NM LIKE %?1%")
//    List<Recipe> findByCkgNmContaining(String search);
    Page<Recipe> findByCkgNmContaining(String search, Pageable pageable);

    @Query("SELECT r FROM Recipe r WHERE r.CKG_MTRL_CN LIKE %?1%")
//    List<Recipe> findByCkgMtrlCnContaining(String search);
    Page<Recipe> findByCkgMtrlCnContaining(String search, Pageable pageable);
}

