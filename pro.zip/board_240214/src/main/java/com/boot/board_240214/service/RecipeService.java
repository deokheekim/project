package com.boot.board_240214.service;

import com.boot.board_240214.model.Recipe;
import com.boot.board_240214.repository.RecipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class RecipeService {

    @Autowired
    private RecipeRepository recipeRepository;

//    public List<Recipe> searchRecipes(String search, String recipeType) {
//        List<Recipe> recipes;
//
//        if ("recipeName".equals(recipeType)) {
//            recipes = recipeRepository.findByCkgNmContaining(search);
//        } else if ("ingredients".equals(recipeType)) {
//            recipes = recipeRepository.findByCkgMtrlCnContaining(search);
//        }else {
//            // 검색 종류가 지정되지 않았을 때 기본 검색 (예: 재료로)
//            recipes = recipeRepository.findByCkgMtrlCnContaining(search);
//        }
//
//        return recipes;
//    }

    public Page<Recipe> searchRecipes(String search, String recipeType, Pageable pageable) {
        if ("recipeName".equals(recipeType)) {
            return recipeRepository.findByCkgNmContaining(search, pageable);
        } else if ("ingredients".equals(recipeType)) {
            return recipeRepository.findByCkgMtrlCnContaining(search, pageable);
        } else {
            // 검색 종류가 지정되지 않았을 때 기본 검색 (예: 재료로)
            return recipeRepository.findByCkgMtrlCnContaining(search, pageable);
        }
    }


}

